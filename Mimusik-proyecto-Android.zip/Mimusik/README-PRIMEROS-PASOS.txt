MIMUSIK - PROYECTO ANDROID INICIAL
==================================

Qué incluye
-----------
- Aplicación Android en Kotlin + Jetpack Compose.
- Catálogo online mediante API de Audius (búsqueda y tendencias).
- Reproducción mediante AndroidX Media3.
- Servicio de reproducción multimedia en segundo plano.
- Favoritos locales durante la sesión (aún no persistentes).
- Compilación automática de APK mediante GitHub Actions.

IMPORTANTE
----------
Este es un MVP/prototipo inicial. La API de Audius ofrece acceso de lectura a su catálogo;
la disponibilidad de cada pista y sus permisos dependen de los términos/licencias
del contenido y del servicio. No incluye catálogo de Spotify ni permite descargar
música comercial protegida. Revisa los términos de Audius antes de publicar la app.
La app todavía necesita pruebas en dispositivos reales y mejoras de producción.

CÓMO GENERAR LA APK SOLO CON TU TELÉFONO
----------------------------------------
1. Abre https://github.com en Chrome e inicia sesión o crea una cuenta.
2. Crea un repositorio nuevo llamado Mimusik. Déjalo público o privado.
3. Sube TODOS los archivos y carpetas de este ZIP conservando la estructura.
   En GitHub móvil puedes usar Add file > Upload files desde el navegador.
   Si la subida de carpetas no funciona, usa la opción "Desktop site" de Chrome.
4. En el repositorio, entra en Actions.
5. Abre "Build Mimusik APK" y pulsa "Run workflow".
   También se inicia automáticamente al subir cambios a la rama main.
6. Espera a que el trabajo termine con marca verde.
7. Abre la ejecución terminada, baja hasta Artifacts y descarga "Mimusik-APK".
8. Descomprime el ZIP descargado en el teléfono.
9. Toca app-debug.apk y autoriza la instalación desde Chrome/Archivos si Android lo solicita.

Si Android bloquea la instalación:
Ajustes > Seguridad/Privacidad > Instalar aplicaciones desconocidas >
permite temporalmente a Chrome o Archivos. Instala la APK y vuelve a desactivar
ese permiso si lo deseas.

REQUISITOS
----------
- Teléfono Android con conexión a Internet.
- Navegador Chrome.
- Cuenta gratuita de GitHub.
- No hace falta instalar Android Studio ni tener computadora.

NOTA SOBRE LA COMPILACIÓN
-------------------------
La primera compilación puede tardar varios minutos. Si falla, abre Actions,
entra en el trabajo fallido y copia el mensaje rojo del error para revisarlo.
La APK debug sirve para pruebas personales; para distribuirla públicamente
conviene configurar firma de versión release, política de privacidad,
atribución del catálogo y pruebas de compatibilidad.

package com.mimusik.app

data class Track(
    val id: String,
    val title: String,
    val artist: String,
    val artwork: String?,
    val streamUrl: String
)

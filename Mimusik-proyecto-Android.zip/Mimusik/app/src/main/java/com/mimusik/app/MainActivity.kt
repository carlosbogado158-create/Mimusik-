package com.mimusik.app

import android.content.ComponentName
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.launch

private val Ink = Color(0xFF101014)
private val Panel = Color(0xFF202027)
private val Lime = Color(0xFFB8F34A)

class MainActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var mediaController: MediaController? = null

    override fun onStart() {
        super.onStart()
        val token = SessionToken(this, ComponentName(this, MusicPlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try { mediaController = controllerFuture?.get() } catch (_: Exception) { }
        }, mainExecutor)
    }

    override fun onStop() {
        mediaController = null
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        super.onStop()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MimusikApp(
            onPlay = { track ->
                val c = mediaController
                if (c != null) {
                    c.setMediaItem(MediaItem.Builder().setUri(track.streamUrl)
                        .setMediaId(track.id).build())
                    c.prepare()
                    c.play()
                }
            },
            onToggle = {
                mediaController?.let { if (it.isPlaying) it.pause() else it.play() }
            },
            isPlaying = { mediaController?.isPlaying == true }
        ) }
    }
}

@Composable
fun MimusikApp(
    onPlay: (Track) -> Unit,
    onToggle: () -> Unit,
    isPlaying: () -> Boolean
) {
    val repo = remember { AudiusRepository() }
    val scope = rememberCoroutineScope()
    var tracks by remember { mutableStateOf<List<Track>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    var current by remember { mutableStateOf<Track?>(null) }
    var favorites by remember { mutableStateOf(setOf<String>()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableIntStateOf(0) }

    fun loadTrending() {
        scope.launch {
            loading = true; error = null
            try { tracks = repo.trending() }
            catch (e: Exception) { error = "No se pudo cargar el catálogo. Revisa tu conexión." }
            finally { loading = false }
        }
    }

    LaunchedEffect(Unit) { loadTrending() }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Ink, surface = Panel, primary = Lime,
            onPrimary = Ink, onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    NavigationBarItem(
                        selected = tab == 0, onClick = { tab = 0 },
                        icon = { Icon(Icons.Default.Home, null) },
                        label = { Text("Inicio") }
                    )
                    NavigationBarItem(
                        selected = tab == 1, onClick = { tab = 1 },
                        icon = { Icon(Icons.Default.Search, null) },
                        label = { Text("Buscar") }
                    )
                    NavigationBarItem(
                        selected = tab == 2, onClick = { tab = 2 },
                        icon = { Icon(Icons.Default.Favorite, null) },
                        label = { Text("Favoritos") }
                    )
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)) {
                Spacer(Modifier.height(20.dp))
                Text("MIMUSIK", style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Black, color = Lime)
                Text("Tu música, tu estilo", color = Color.LightGray)
                Spacer(Modifier.height(18.dp))

                if (tab == 1) {
                    OutlinedTextField(
                        value = query, onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Busca canciones o artistas") },
                        singleLine = true,
                        trailingIcon = {
                            IconButton(onClick = {
                                if (query.isNotBlank()) scope.launch {
                                    loading = true; error = null
                                    try { tracks = repo.search(query) }
                                    catch (e: Exception) { error = "Error al buscar. Intenta nuevamente." }
                                    finally { loading = false }
                                }
                            }) { Icon(Icons.Default.Search, "Buscar") }
                        }
                    )
                    Spacer(Modifier.height(12.dp))
                } else {
                    Text(
                        when (tab) { 2 -> "TUS FAVORITOS"; else -> "MÚSICA EN TENDENCIA" },
                        style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold
                    )
                }

                if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
                error?.let { Text(it, color = Color(0xFFFF8A80), modifier = Modifier.padding(8.dp)) }

                val visible = if (tab == 2) tracks.filter { favorites.contains(it.id) } else tracks
                if (visible.isEmpty() && !loading && error == null) {
                    Text(if (tab == 2) "Aún no tienes favoritos." else "No hay canciones para mostrar.",
                        color = Color.LightGray, modifier = Modifier.padding(16.dp))
                }

                LazyColumn(modifier = Modifier.weight(1f)) {
                    items(visible, key = { it.id }) { track ->
                        Row(
                            Modifier.fillMaxWidth().clickable {
                                current = track; onPlay(track)
                            }.padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                modifier = Modifier.size(52.dp),
                                shape = RoundedCornerShape(10.dp),
                                color = Panel
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text("♫", color = Lime, style = MaterialTheme.typography.headlineMedium)
                                }
                            }
                            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                                Text(track.title, maxLines = 1, fontWeight = FontWeight.SemiBold)
                                Text(track.artist, maxLines = 1, color = Color.LightGray,
                                    style = MaterialTheme.typography.bodySmall)
                            }
                            IconButton(onClick = {
                                favorites = if (favorites.contains(track.id))
                                    favorites - track.id else favorites + track.id
                            }) {
                                Icon(Icons.Default.Favorite, null,
                                    tint = if (favorites.contains(track.id)) Lime else Color.Gray)
                            }
                        }
                        HorizontalDivider(color = Panel)
                    }
                }

                current?.let { track ->
                    Surface(color = Panel, shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(track.title, maxLines = 1, fontWeight = FontWeight.Bold)
                                Text(track.artist, color = Color.LightGray,
                                    style = MaterialTheme.typography.bodySmall)
                            }
                            IconButton(onClick = onToggle) {
                                Icon(
                                    if (isPlaying()) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = "Reproducir o pausar",
                                    tint = Lime
                                )
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

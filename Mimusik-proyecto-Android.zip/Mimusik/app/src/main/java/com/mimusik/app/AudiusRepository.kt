package com.mimusik.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder

class AudiusRepository {
    private val client = OkHttpClient()
    private val base = "https://api.audius.co/v1"
    private val appName = "MimusikAndroid"

    suspend fun search(query: String): List<Track> = withContext(Dispatchers.IO) {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val url = "$base/tracks/search?query=$encoded&limit=25&app_name=$appName"
        val request = Request.Builder().url(url).get().build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Audius respondió: ${response.code}")
            val json = JSONObject(response.body?.string() ?: "{}")
            val data = json.optJSONArray("data") ?: return@withContext emptyList()
            buildList {
                for (i in 0 until data.length()) {
                    val item = data.optJSONObject(i) ?: continue
                    val id = item.optString("id")
                    if (id.isBlank() || id == "null") continue
                    val user = item.optJSONObject("user")
                    val artworkObj = item.optJSONObject("artwork")
                    val artwork = artworkObj?.optString("150x150")?.takeIf {
                        !it.isNullOrBlank() && it != "null"
                    }
                    add(
                        Track(
                            id = id,
                            title = item.optString("title", "Sin título"),
                            artist = user?.optString("name", "Artista") ?: "Artista",
                            artwork = artwork,
                            streamUrl = "$base/tracks/$id/stream?app_name=$appName"
                        )
                    )
                }
            }
        }
    }

    suspend fun trending(): List<Track> = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url("$base/tracks/trending?limit=25&app_name=$appName")
            .get().build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Audius respondió: ${response.code}")
            val json = JSONObject(response.body?.string() ?: "{}")
            val data = json.optJSONArray("data") ?: return@withContext emptyList()
            buildList {
                for (i in 0 until data.length()) {
                    val item = data.optJSONObject(i) ?: continue
                    val id = item.optString("id")
                    if (id.isBlank() || id == "null") continue
                    val user = item.optJSONObject("user")
                    val art = item.optJSONObject("artwork")?.optString("150x150")
                    add(Track(
                        id, item.optString("title", "Sin título"),
                        user?.optString("name", "Artista") ?: "Artista",
                        art?.takeIf { it.isNotBlank() && it != "null" },
                        "$base/tracks/$id/stream?app_name=$appName"
                    ))
                }
            }
        }
    }
}
